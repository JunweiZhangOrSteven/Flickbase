import { AdminTitle } from '../../utils/tools'

const DashboardMain = () => {
    return(
        <>
            <AdminTitle title="Dashboard"/>
            Dashboard main
        </>
    )
}

export default DashboardMain;